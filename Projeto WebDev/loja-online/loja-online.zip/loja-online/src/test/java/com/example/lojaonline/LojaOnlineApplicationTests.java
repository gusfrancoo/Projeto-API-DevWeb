package com.example.lojaonline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LojaOnlineApplicationTests {

	@Test
	void contextLoads() {
	}

}
