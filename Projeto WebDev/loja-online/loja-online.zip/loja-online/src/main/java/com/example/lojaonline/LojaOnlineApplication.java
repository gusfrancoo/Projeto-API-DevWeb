package com.example.lojaonline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LojaOnlineApplication {

	public static void main(String[] args) {
		SpringApplication.run(LojaOnlineApplication.class, args);
	}

}
